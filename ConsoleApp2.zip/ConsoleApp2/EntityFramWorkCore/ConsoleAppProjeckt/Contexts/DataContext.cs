﻿

using ConsoleAppProjeckt.Models.Entites;
using Microsoft.EntityFrameworkCore;

namespace ConsoleAppProjeckt.Contexts;

internal class DataContext : DbContext


{
    public DataContext()
    {
    }
    public DataContext(DbContextOptions<DataContext> options) : base(options)
    {
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\elie-\OneDrive\Desktop\ConsoleApp2\EntityFramWorkCore\ConsoleAppProjeckt\Contexts\EntityDb3.mdf;Integrated Security=True;Connect Timeout=30");
    }

    public DbSet<StatusEntity> statuses { get; set; }
    public DbSet<UserEntity> Users { get; set; }

    public DbSet<CaseEntity> cases { get; set; }

    public DbSet<CommentEntity> Comments { get; set; }


}

