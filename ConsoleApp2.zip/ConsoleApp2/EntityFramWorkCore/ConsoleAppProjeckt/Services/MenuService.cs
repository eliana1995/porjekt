﻿

using ConsoleAppProjeckt.Models.Entites;

namespace ConsoleAppProjeckt.Services;

    internal class MenuService
    {
    private readonly UserService _userService = new();
    private readonly CaseService _caseService = new();

    public async Task<UserEntity> CreateUserAsync()
    {
        var _entity = new UserEntity();
        Console.Clear();
        Console.WriteLine("######## new supervisor########");
        Console.WriteLine("enter first name");
        _entity.FirstName = Console.ReadLine() ?? "";
        Console.WriteLine("enter last name");
        _entity.LastName = Console.ReadLine() ?? "";
        Console.WriteLine("enter email");
        _entity.Email = Console.ReadLine() ?? "";

      return  ( await _userService.CreateAsync(_entity));
    }

    public async Task MainMenu(int userId) 
    {
        Console.Clear();
        Console.WriteLine("######## Menu ########");
        Console.WriteLine("1. Visa alla aktiva ärenden");
        Console.WriteLine("2. Visa alla handläggare");
        Console.WriteLine("3. Skapa nytt ärende");
        Console.Write("Välj ett av ovanståebde alternaiv");
        var option = Console.ReadLine();

        switch(option) 
        {
            case "1":
               await ActiveCasesAsync();
                break;

            case "2":
                await HandlersAsync();
                break;

            case "3":
                await NewCaseAsync (userId);
                break;

            default:
                Console.Clear();
                Console.Write("no valid choice was entered");
                break;
        }
    }

    private async Task ActiveCasesAsync() 
    {

        Console.Clear();
        Console.WriteLine("######## ärende Menu ########");
       foreach(var _case in await _caseService.GetAllActiveAsync())
        {
            Console.WriteLine($"kund: {_case.Id}");
            Console.WriteLine($"Created : {_case.Created}");
            Console.WriteLine($"Modified: {_case.Modified}");
            Console.WriteLine($"Status: {_case.Status.StatusName}");
            Console.WriteLine("");
        }
    }

    private async Task HandlersAsync()
    
    {

        Console.Clear();
        Console.WriteLine("######## handledare ########");
        foreach (var _user in await _userService.GetAllAsync())
        {
            Console.WriteLine($"supervisor: {_user.Id}");
            Console.WriteLine($"name : {_user.FirstName} {_user.LastName}");
            Console.WriteLine($"E-post: {_user.Email}");
            
            Console.WriteLine("");
        }
    }

    private async Task NewCaseAsync(int userId)
    {
        var _entity = new CaseEntity { UserId = userId};
        Console.Clear();
        Console.WriteLine("######## new matter ########");
        Console.WriteLine("enter customer name");
        _entity.CustomerName = Console.ReadLine() ?? "";
        Console.WriteLine("enter customer e-post");
        _entity.CustomerEmail = Console.ReadLine() ?? "";
        Console.WriteLine("enter a description of the matter");
        _entity.Description = Console.ReadLine() ?? "";



        await _caseService.CreateAsync(_entity);
        await ActiveCasesAsync();
    }


}

