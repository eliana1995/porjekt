﻿

using ConsoleAppProjeckt.Contexts;
using ConsoleAppProjeckt.Models.Entites;
using Microsoft.EntityFrameworkCore;

namespace ConsoleAppProjeckt.Services;

    internal class StatusService
    {
    private readonly DataContext _context = new ();

    public async Task CreateStatusTypesAsync()
    {
        if (!await _context.statuses.AnyAsync())
        {
            string[] _statuses = new string[] { "Ej påbörjad", "Pågående", "Avslutad" };

            foreach (var status in _statuses)
            {
                await _context.AddAsync(new StatusEntity { StatusName = status });
                await _context.SaveChangesAsync();
            }

           
        }
    }


    }

